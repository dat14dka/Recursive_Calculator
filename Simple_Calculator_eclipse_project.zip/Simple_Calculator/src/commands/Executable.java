package commands;

public interface Executable {
	public boolean excecute();
}
